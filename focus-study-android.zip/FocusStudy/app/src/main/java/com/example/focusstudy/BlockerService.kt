package com.example.focusstudy

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class BlockerService : AccessibilityService() {

    private var lastToast = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        val prefs = getSharedPreferences("focus", MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now >= prefs.getLong("endAt", 0L)) return

        val blocked = prefs.getStringSet("blocked", setOf("com.google.android.youtube")) ?: return
        if (pkg in blocked) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            if (now - lastToast > 2000) {
                lastToast = now
                Toast.makeText(this, "अभी फ़ोकस टाइम है, पढ़ाई करो 📚", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onInterrupt() {}
}
