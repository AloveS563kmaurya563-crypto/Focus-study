package com.example.focusstudy

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var clock: TextView
    private lateinit var status: TextView
    private lateinit var todayView: TextView
    private lateinit var minutesInput: EditText
    private lateinit var startBtn: Button
    private lateinit var accBtn: Button

    private var doneMessage = ""

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun todayKey() = "min_" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("focus", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setBackgroundColor(Color.parseColor("#0F172A"))
        root.setPadding(dp(24), dp(48), dp(24), dp(24))

        fun label(size: Float, color: String, bold: Boolean): TextView {
            val t = TextView(this)
            t.textSize = size
            t.setTextColor(Color.parseColor(color))
            t.gravity = Gravity.CENTER
            if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
            return t
        }

        fun add(v: View, top: Int) {
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(top)
            root.addView(v, lp)
        }

        val title = label(22f, "#F1F5F9", true)
        title.text = "📚 Focus Study"
        add(title, 0)

        clock = label(64f, "#38BDF8", true)
        add(clock, 24)

        status = label(14f, "#94A3B8", false)
        add(status, 4)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        minutesInput = EditText(this)
        minutesInput.inputType = InputType.TYPE_CLASS_NUMBER
        minutesInput.setText("25")
        minutesInput.setTextColor(Color.WHITE)
        minutesInput.gravity = Gravity.CENTER
        minutesInput.textSize = 20f
        row.addView(minutesInput, LinearLayout.LayoutParams(dp(100), LinearLayout.LayoutParams.WRAP_CONTENT))
        val unit = label(16f, "#94A3B8", false)
        unit.text = "  मिनट"
        row.addView(unit)
        add(row, 16)

        startBtn = Button(this)
        startBtn.textSize = 18f
        startBtn.setOnClickListener {
            if (isRunning()) endSession() else startSession()
            refresh()
        }
        add(startBtn, 16)

        val appsBtn = Button(this)
        appsBtn.text = "ब्लॉक करने वाले ऐप चुनो"
        appsBtn.setOnClickListener { pickApps() }
        add(appsBtn, 12)

        accBtn = Button(this)
        accBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        add(accBtn, 12)

        todayView = label(16f, "#34D399", true)
        add(todayView, 28)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    private fun isRunning() = prefs.getLong("endAt", 0L) > System.currentTimeMillis()

    private fun accEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return s != null && s.contains(packageName)
    }

    private fun blockedSet(): Set<String> =
        prefs.getStringSet("blocked", setOf("com.google.android.youtube"))?.toSet() ?: emptySet()

    private fun startSession() {
        val m = (minutesInput.text.toString().toIntOrNull() ?: 25).coerceIn(1, 600)
        val now = System.currentTimeMillis()
        doneMessage = ""
        prefs.edit().putLong("startAt", now).putLong("endAt", now + m * 60_000L).apply()
    }

    private fun endSession() {
        val startAt = prefs.getLong("startAt", 0L)
        val endAt = prefs.getLong("endAt", 0L)
        val stopAt = minOf(System.currentTimeMillis(), endAt)
        val mins = ((stopAt - startAt) / 60_000L).toInt()
        val e = prefs.edit()
        if (mins >= 1) e.putInt(todayKey(), prefs.getInt(todayKey(), 0) + mins)
        e.putLong("endAt", 0L).putLong("startAt", 0L).apply()
    }

    private fun refresh() {
        val now = System.currentTimeMillis()
        val endAt = prefs.getLong("endAt", 0L)

        if (endAt > now) {
            val s = (endAt - now + 999) / 1000
            clock.text = String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
            startBtn.text = "रोको"
            minutesInput.isEnabled = false
            status.text = if (accEnabled()) "फ़ोकस चालू है, चुने हुए ऐप बंद 🔒"
            else "⚠️ ऐप ब्लॉकिंग चालू करने के लिए नीचे वाला बटन दबाओ"
        } else {
            if (endAt != 0L) {
                endSession()
                doneMessage = "सेशन पूरा हुआ! 🎉"
            }
            val m = (minutesInput.text.toString().toIntOrNull() ?: 25).coerceIn(1, 600)
            clock.text = String.format(Locale.US, "%02d:00", m)
            startBtn.text = "शुरू करो"
            minutesInput.isEnabled = true
            status.text = if (doneMessage.isNotEmpty()) doneMessage else "तैयार हो? टाइमर शुरू करो"
        }

        accBtn.text = if (accEnabled()) "✅ ऐप ब्लॉकिंग चालू है" else "ऐप ब्लॉकिंग चालू करो (Accessibility)"
        todayView.text = "आज की पढ़ाई: ${prefs.getInt(todayKey(), 0)} मिनट"
    }

    private fun pickApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }

        val selected = blockedSet().toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].second in selected }

        AlertDialog.Builder(this)
            .setTitle("पढ़ाई के समय कौन से ऐप बंद करें?")
            .setMultiChoiceItems(apps.map { it.first }.toTypedArray(), checked) { _, which, isChecked ->
                if (isChecked) selected.add(apps[which].second) else selected.remove(apps[which].second)
            }
            .setPositiveButton("सेव") { _, _ ->
                prefs.edit().putStringSet("blocked", HashSet(selected)).apply()
            }
            .setNegativeButton("रद्द", null)
            .show()
    }
}
